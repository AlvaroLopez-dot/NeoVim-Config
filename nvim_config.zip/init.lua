require('config.options')
require('config.keybinds')
require('config.lazy')
vim.opt.rtp:append("/home/alva/.local/share/nvim/site")
vim.opt.clipboard = "unnamedplus"

-- Resize vertical splits using Alt (Meta) + h/l keys
vim.keymap.set('n', '<M-h>', ':vertical resize -2<CR>', { silent = true })
vim.keymap.set('n', '<M-l>', ':vertical resize +2<CR>', { silent = true })

local luasnip = require("luasnip")

vim.api.nvim_create_autocmd("InsertLeave", {
  callback = function()
    if luasnip.session.current_nodes[vim.api.nvim_get_current_buf()]
      and not luasnip.session.jump_active
    then
      luasnip.unlink_current()
    end
  end,
})
