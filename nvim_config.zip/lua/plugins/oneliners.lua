return {
	{ -- Helps with shh tunneling and copying to clipboard
		'ojroques/vim-oscyank',
	},
	{ -- Git plugin
		'tpope/vim-fugitive',
	},
	{ -- Show CSS colors
		'brenoprata10/nvim-highlight-colors',
		config = function()
			require('nvim-highlight-colors').setup({})
		end
	},
	{ -- Show mini icons
		'nvim-mini/mini.icons',
		version = false
	},
}
